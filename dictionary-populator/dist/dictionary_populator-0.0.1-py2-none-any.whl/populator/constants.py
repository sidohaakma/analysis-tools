DICT_MONTHLY_REPEATED_MEASURES = 'monthly_repeated_measures'
DICT_YEARLY_REPEATED_MEASURES = 'yearly_repeated_measures'
DICT_NON_REPEATED_MEASURES = 'non_repeated_measures'
PROJECT = 'lifecycle'
