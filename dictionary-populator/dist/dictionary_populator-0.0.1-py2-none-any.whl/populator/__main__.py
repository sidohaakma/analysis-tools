
import populator

def main():
    populator.populate()